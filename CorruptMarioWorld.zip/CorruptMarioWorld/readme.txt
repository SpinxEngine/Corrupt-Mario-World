To play this ROM Hack, open the .smc file in an SNES Emulator (i recommend Snes9x).
If you want to change stuff to this ROM Hack, open the .mwl file in Lunar Magic!

Also credit me if you want to reupload this rom hack to your website :)
